# Ziria-Mod

This is the first mod i have made. Link to the discord server for discussing my mod:
<https://discord.gg/HpAyyyD75K>

