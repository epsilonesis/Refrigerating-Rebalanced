Events.on(ContentInitEvent, e => {
     Vars.content.block("testmod-pink-ice-floor").attributes.set(Attribute.get("pink-ice"), 1);

     Vars.content.block("testmod-ice-drill").attribute = Attribute.get("pink-ice");
});